import { upperCase, localeUpperCase } from "upper-case";

console.log(upperCase("string"))
console.log(upperCase("string1"))
console.log(upperCase("string2"))
