const data = require('./data')

console.log(data['game'])
console.log(data.players)
console.log(data.players.country.country1)




// {
//     "game": "football",
//     "players":{
//         "name":"Messi",
//         "country":{

// }
//     }
// }