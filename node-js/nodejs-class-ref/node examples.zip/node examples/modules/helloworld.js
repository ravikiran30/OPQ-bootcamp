const add1 = require("./add")


console.log("This is the Hello Word statement");
console.log(add1(2,4))