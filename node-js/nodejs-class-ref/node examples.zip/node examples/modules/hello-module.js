const add  = require('./add')

console.log("This is the Hello Word statement");
console.log(add(2,3))
