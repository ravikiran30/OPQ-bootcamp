const math = require('./math')

const { add, subract} = math ;

console.log(add(2,5))
console.log(subract(2,5))

// console.log(add(2,5))
// console.log(subract(2,5))
