// const add = function (a, b ){
// 	return a + b
// }

// // sum = add(2,3);
// // console.log(sum);

// module.exports = add;  

module.exports = function (a, b ){
	return a + b
}