// const add = function (a, b ){
// 	return a + b
// }

// const subract = function (a, b ){
// 	return a - b
// }


// module.exports = {
// 	add: add,
// 	subract: subract
// };  



module.exports.add = function (a, b ){
	return a + b
}

module.exports.subract = function (a, b ){
	return a - b
}